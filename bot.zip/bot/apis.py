import requests
import json
import re
def hackerTarget(address):
    try:
        response = requests.get("https://api.hackertarget.com/reverseiplookup/?q="+address)
        if response.status_code != 200:
            return False
        if " " in response.text.split("\n")[0]:
            return False
        return response.text.split("\n")
    except Exception:
        return False

def youGetSignal(address):
    _api = "https://domains.yougetsignal.com/domains.php"
    _data = {'remoteAddress': address}
    _headers = {
        'Host': "domains.yougetsignal.com",
        'Connection': "keep-alive",
                'Cache-Control': "no-cache",
                'Origin': "http://www.yougetsignal.com",
                'User-Agent': "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/53.0.2785.143 Chrome/53.0.2785.143 Safari/537.36",
    }
    try:
        response = requests.post(
            _api,
            headers=_headers,
            data=_data,
            timeout=15)
        if response.status_code != 200:
            return False
        response = response.content
        _json = json.loads(response)
        if _json['status'] == 'Fail':
            return False
        doms = list(set(map(lambda d:(d[0]),_json["domainArray"])))
        return doms
    except Exception:
        return False

def rapidDNS(address):
    try:
	    names = []
	    response = requests.get("https://rapiddns.io/sameip/" + address + "?full=1#result").content.decode("utf-8")
	    pattern = r"</th>\n<td>(.*?)</td>"
	    results = re.findall(pattern, response)
	    for line in results:
	        line = line.strip()  #delete ' '
	        if line.startswith("www."):
	            line = "" + line[4:]
	        if line not in names:
	            names.append(line)
	    if len(names) > 0:
	        return names
	    return False
    except Exception:
        return False

def choiceApi(address):
    result = hackerTarget(address)
    if result:
        return result
    result = youGetSignal(address)
    if result:
        return result
    result = rapidDNS(address)
    return result

def allApis(address):
    allResults = []
    result = hackerTarget(address)
    if result:
        allResults += result
    result = youGetSignal(address)
    if result:
        allResults += result
    result = rapidDNS(address)
    if result:
        allResults += result
    return list(set(allResults))
