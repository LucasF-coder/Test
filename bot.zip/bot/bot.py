import socket
import telebot
import requests
import json
import threading
import time
import schedule
import sys
import re
import apis

from threading import Thread
ids = [5085724647]
users = open("users.txt","r").read().split("\n")

bot = telebot.TeleBot("5840757299:AAFVes1DDAqG0YXzlZ6klGnZ17Sa2LU4hUM", parse_mode="HTML")
banco = json.loads(open("banco2.json","r").read())

#utils


class threadreturn(threading.Thread):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.result = None
    def run(self):
        if self._target is None:
            return
        try:
            self.result = self._target(*self._args, **self._kwargs)
        except Exception as exc:
            pass
            #print(f'{type(exc).__name__}: {exc}', file=sys.stderr)
    def join(self, *args, **kwargs):
        super().join(*args, **kwargs)
        return self.result

def save(data,dirName,filtrar=False):
#    print("Escrevendo: "+dirName)
    try:
        if filtrar:
            bnc = open(dirName,"r").read().split("\n")
            if str(data) in bnc: return
        with open(dirName,'a') as fl:
            fl.write(str(data)+'\n')
            fl.close()
    except:
        open(dirName,"w").write(str(data)+"\n")


def salvarDominios():
    print("Salvando")
    open("banco.json","w").write(json.dumps(banco))
    print("Salvo")
    bot.send_message(5085724647,"Banco de dominios salvos")

def agendarSave():
    schedule.every().day.at("00:00").do(salvarDominios)
    while True:
        schedule.run_pending()
        time.sleep(1)
threading.Thread(target=agendarSave).start()

def get_ip_by_domain(domain):
    global banco
    for address in banco:
        if domain in banco[address]:
            return address
    return None


def get_urls_from_website(url):
    try:
        headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36'}
        response = requests.get(url,headers=headers)
        response.raise_for_status()
        content = response.text
        urls = re.findall(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', content)
        return urls
    except:
        return []


def serverFind(ip):
 try:
  ip = ip.replace("https://","").replace("http://","")
  server = ""
  try:
   protocolo = "https"
   if ip.replace(".","").isnumeric():
    protocolo = "http"
   server = requests.get(protocolo+"://"+ip,timeout=2)
   if server.headers.get("x-cdn") != None:
    server = server.headers["x-cdn"]
   else:
    server = server.headers["server"]
  except:
   port = 80
   sc=socket.socket()
   sc.settimeout(2)
   sc.connect((str(ip),port))
   payload=f'GET / HTTP/1.1[crlf]Host: cloudflare.com[crlf][crlf]'
   payload=payload.replace('[crlf]','\r\n')
   sc.send(payload.encode())
   packet = sc.recv(1024).decode('utf-8','ignore')
   server = packet.split("\r")
   server = list(filter(lambda x:("Server:" in x),server))
   server = server[0].replace("\n","").replace("Server: ","")
  return ip + " - " +server
 except:
  return False







def getIp(domain):
    if domain.replace(".","").isnumeric():
        return False
    try:
        ip = socket.gethostbyname(domain)
        return ip
    except:
        return False

def filtrarByIp(ipp,domains):
    doms = []
    for d in domains:
        ip2 = getIp(d)
        if ip2 == ipp:
            doms.append(d)
        elif ip2:
               
            if ip2.replace(".","-") in banco:
                if not d in banco[ip2.replace(".","-")]:
                    banco[ip2.replace(".","-")].append(d)
            else:
                banco[ip2.replace(".","-")] = [d]
#            banco[ipp.replace(".","-")] = list(set(filter(lambda x:(x != d),banco[ipp.replace(".","-")])))
    return doms



def getDoms(address):
    global banco
    address = address.replace("https","").replace("http","").replace("/","")
    if not address.replace(".","").isnumeric():
        try:
            address = socket.gethostbyname(address)
        except:
            address = ""
    result = banco.get(address.replace(".","-"))
    if not result:
        result = []
    if not result:
        results = apis.choiceApi(address)
        if results:
            result += results
    elif len(result) <= 1:
        results = apis.allApis(address)
        if results:
            result += results
    result = list(set(result))
    if len(result) > 0:
        banco[address.replace(".","-")] = result
    return result
    
    


#comandos
@bot.message_handler(commands=['start', 'help'])
def start(message):
    if not (message.text == "/start" or message.text == "start" or message.text == ""):
        return
    bot.reply_to(message,"Pegar dominios do mesmo ip: /reverse ip ou dominio\nExemplos: <b>/reverse mobilidade.cloud.caixa.gov.br</b> ou <b>/reverse 104.16.56.6</b>\nPode ser usado /look em vez de /reverse.\n\nVer servidor do ip/dominio\nExemplo: /server ip1,ip2,ip3,...\nPode ser usado dominios invés de ips\nTambém é aceito quebra de linha em vez de virgula.\n\nPegar urls dentro de um site: /urls dominio\nExemplos: <b>/urls vivo.com.br</b>")
    if not message.from_user.id in users:
        save(message.from_user.id,"users.txt",True)
        users.append(message.from_user.id)

@bot.message_handler(commands=['urls', 'url'])
def urls(message):
    msg = message.text.split(" ")
    urlss = []
    if len(msg) > 1:
        msg = msg[1].replace("https://","").replace("http://","")
    else:
        msg = None
    if not msg:
        return bot.reply_to(message,"Pegar urls dentro de um site: /urls dominio\nExemplos: <b>/urls vivo.com.br</b>")
    if "//" in msg:
        urlss = get_urls_from_website(msg)
    if len(urlss) == 0:
        urlss = get_urls_from_website("https://"+msg)
    if len(urlss) == 0:
        urlss = get_urls_from_website("http://"+msg)
    if len(urlss) > 0:
        urlss = "\n".join(list(set(urlss)))
        if len(urlss) >= 4090:
            open("urls.txt","w").write(urlss)
            doc = open('urls.txt', 'rb')
            bot.send_document(message.chat.id,doc)
        else:
            bot.reply_to(message,urlss)
    else:
        return bot.reply_to(message,"Nada encontrado")


@bot.message_handler(commands=['reverse', 'look'])
def reverse(message):
    global banco
    msg = message.text.split(" ")
    if len(msg) > 1:
        msg = msg[1].replace("https://","").replace("http://","")
    else:
        msg = None
    ipp = None
    if not msg:
        return bot.reply_to(message,"Pegar dominios do mesmo ip: /reverse ip ou dominio\nExemplos: <b>/reverse mobilidade.cloud.caixa.gov.br</b> ou <b>/reverse 104.16.56.6</b>\nPode ser usado /look em vez de /reverse.")
    toSend = None
    results = getDoms(msg)
    if results:
        toSend = "\n".join(results)
        if msg.replace(".","").isnumeric():
            ipp = msg
        else:
            ipp = socket.gethostbyname(msg)
    if not toSend:
        ipp = get_ip_by_domain(msg)
        if ipp:
            toSend = "\n".join(banco[ipp])
            ipp = ipp.replace("-",".")
    if not toSend:
        return bot.reply_to(message,"Nada encontrado")
    else:
#        Thread(target=filtrarByIp,args=[ipp,toSend.split("\n")]).start()
        #banco[ipp.replace(".","-")] = toSend
      #  toSend = "\n".join(toSend)
        toSend = "ip: "+ipp+"\n\n"+toSend
        if len(toSend) >= 4090:
            open("look.txt","w").write(toSend)
            doc = open('look.txt', 'rb')
            return bot.send_document(message.chat.id,doc)
        else:
            return bot.reply_to(message,toSend)
    return bot.reply_to(message,"Nada encontrado")



@bot.message_handler(commands=['anunciar'])
def anunciar(message):
    global users
    if not message.from_user.id in ids:
        return
    msg = " ".join(message.text.split(" ")[1:])
    bot.send_message(message.from_user.id,"Enviando: "+msg)
    def send(id,mensagem):
        try:
            bot.send_message(id,mensagem)
            print("Enviado ao: "+ id)
        except:
            print("Falha em enviar ao: "+id)
            pass
    threads = []
    for user in users:
        th = Thread(target=send,args=[user,msg])
        threads.append(th)
        th.start()
    for th in threads:
        th.join()
    bot.send_message(message.from_user.id,"Aviso enviado para todos.")

    
    

    
@bot.message_handler(commands=['server'])
def server(message):
 try:
  global sv
  result = []
  text = " ".join(message.text.split(" ")[1:])
  if text == "":
   return bot.reply_to(message,"Exemplo: /server ip1,ip2,ip3,...\nPode ser usado dominios invés de ips\nTambém é aceito quebra de linha invés de virgula.")
  msg = ",".join(message.text.split(" ")[1:])
  domains = ",".join(msg.split("\n")).split(",")
  domains = list(set(filter(lambda x: (len(x) > 2),domains)))
  bot.reply_to(message,"Verificando...")
  thread1 = []
  for x in domains:
   th = threadreturn(target=serverFind, args=(x,))
   thread1.append(th)
   th.start()
   time.sleep(0.2)
  for x in thread1:
   result.append(x.join())
  result = list(filter(lambda x: (x != False),result))
  if len(result) == 0:
   if len(domains) == 1:
    return bot.reply_to(message,"Não foi possivel acessar o nome do servidor do dominio.")
   else:
    return bot.reply_to(message,"Não foi possivel acessar os nomes dos servidores dos dominios.")
  if len("\n".join(result)) >= 4090:
   open("servers.txt","w").write("\n".join(result))
   doc = open('servers.txt', 'rb')
   bot.send_document(message.chat.id,doc)
  else:
   bot.reply_to(message,"\n".join(result))
   domains = list(map(lambda y:(y.split(" ")[0]),result))
   for x in domains:
    if not x.replace(".","").isnumeric():
      try:
        ip = socket.gethostbyname(x)
        if banco.get(ip.replace(".","-")) != None:
          if not x in banco[ip.replace(".","-")]:
            Thread(target=saveDomains,args=(ip,[x])).start()
      except:
        pass
 except Exception as err:
  print(err)
  pass

@bot.message_handler(func=lambda message: True)
def test(message):
#    if not message.from_user.id in ids:
#        return
    msg = message.text.split(" ")
 #   urls = list(set(filter(lambda x:(".com" in x),msg)))
    urls = list(set(filter(lambda x: re.search(r'\.[A-z]{2,3}', x), msg)))
#    print(urls)
    if len(urls) == 0:
        return
    results = []
    threads = []
    for url in urls:
        if "://" in url:
            url = url.split("://")[1]
        th = threadreturn(target=socket.gethostbyname,args=[url])
        threads.append(th)
        th.start()
    for th in threads:
        results.append(th.join())
#    print(results)
    for url, result in zip(urls, results):
        if result != None and result != "None":
            ipp = result.replace(".","-")
            if ipp in banco:
                if not url in banco[ipp]:
                    banco[ipp].append(url)
            else:
                banco[ipp].append(url)
    
try:
 print("Iniciado.")
 bot.infinity_polling()
except:
 pass
